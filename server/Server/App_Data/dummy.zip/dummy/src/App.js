import logo from './logo.svg';
import React, {useCallback, useState} from 'react'
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import Button from '@material-ui/core/Button';
import './App.css';
const useStyles = makeStyles((theme) => ({ root: { flexGrow: 1, padding: 10 }, rightMargin: { marginRight: 120 }, rightFloat: { float: 'right', top: -40 } }));
function App() {
const classes = useStyles();
const [query_petId, Set_query_petId] = useState('')
const onSubmit = useCallback((event) => {
event.preventDefault();
const requestOptions = {
method: 'GET',
headers: { 'Content-Type': 'application/json' },
};
fetch('https://petstore.swagger.io/v2/pet/'+query_petId, requestOptions)
.then(response => response.json())
.then(data => console.log(data))
.catch (err => console.log(err));
})

return (
<form className={classes.root} noValidate autoComplete='off' onSubmit={onSubmit}>
<h1></h1>
<Grid container spacing={3}>
<Grid item xs={12}>
<TextField label='petId' helperText='' type='number'  onInput={ e=>Set_query_petId(e.target.value)} fullWidth />
</Grid>

<Grid item xs={12}><Button variant='contained' color='primary' type='submit'>Submit</Button></Grid>

</Grid>
</form>
);
}
export default App;
